/**
 * @license Highcharts JS v8.2.0 (2020-08-20)
 * @module highcharts/modules/streamgraph
 * @requires highcharts
 *
 * Streamgraph module
 *
 * (c) 2010-2019 Torstein Honsi
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../Series/StreamgraphSeries.js';
