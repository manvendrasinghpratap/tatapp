/**
 * @license Highcharts JS v8.2.0 (2020-08-20)
 * @module highcharts/modules/dumbbell
 * @requires highcharts
 *
 * (c) 2009-2019 Sebastian Bochan, Rafal Sebestjanski
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../Series/DumbbellSeries.js';
