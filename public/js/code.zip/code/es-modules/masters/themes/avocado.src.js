/**
 * @license Highcharts JS v8.2.0 (2020-08-20)
 * @module highcharts/themes/avocado
 * @requires highcharts
 *
 * (c) 2009-2019 Highsoft AS
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../Extensions/Themes/Avocado.js';
